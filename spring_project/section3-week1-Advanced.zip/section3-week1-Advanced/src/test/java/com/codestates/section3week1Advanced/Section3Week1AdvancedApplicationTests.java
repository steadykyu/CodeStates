package com.codestates.section3week1Advanced;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Section3Week1AdvancedApplicationTests {

	@Test
	void contextLoads() {
	}

}
