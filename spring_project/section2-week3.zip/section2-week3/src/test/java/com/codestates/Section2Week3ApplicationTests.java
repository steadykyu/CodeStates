package com.codestates;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Section2Week3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
